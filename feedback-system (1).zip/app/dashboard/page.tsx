"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { PlusCircle, Star, Edit } from "lucide-react"
import Header from "@/app/components/header"

// Define types for our data
interface Teacher {
  id: string
  name: string
  department: string
  subject: string
  rating: number
  feedback: string
}

export default function Dashboard() {
  // In a real app, this would come from a database
  const [teachers, setTeachers] = useState<Teacher[]>([])

  useEffect(() => {
    // Load teachers from localStorage if available
    const savedTeachers = localStorage.getItem("teachers")
    if (savedTeachers) {
      setTeachers(JSON.parse(savedTeachers))
    }
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-pink-100">
      <Header />

      <main className="container mx-auto p-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <h1 className="text-3xl font-bold text-pink-600">My Teachers</h1>
          <Link href="/add-teacher">
            <Button className="bg-pink-600 hover:bg-pink-700">
              <PlusCircle className="mr-2 h-4 w-4" />
              Add New Teacher
            </Button>
          </Link>
        </div>

        {teachers.length === 0 ? (
          <div className="rounded-lg bg-white p-8 text-center shadow">
            <h2 className="mb-2 text-xl font-semibold">No Teachers Added Yet</h2>
            <p className="mb-4 text-gray-600">Start by adding a teacher to evaluate</p>
            <Link href="/add-teacher">
              <Button className="bg-pink-600 hover:bg-pink-700">
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Your First Teacher
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {teachers.map((teacher) => (
              <Card key={teacher.id} className="overflow-hidden">
                <CardHeader className="bg-pink-100 pb-2">
                  <CardTitle>{teacher.name}</CardTitle>
                  <CardDescription>
                    {teacher.department} • {teacher.subject}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-4">
                  <div className="mb-2 flex items-center">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-5 w-5 ${
                            i < teacher.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="ml-2 text-sm font-medium">{teacher.rating}/5</span>
                  </div>
                  <p className="text-sm text-gray-600">{teacher.feedback}</p>
                </CardContent>
                <CardFooter className="border-t bg-gray-50 px-6 py-3">
                  <Link href={`/evaluate/${teacher.id}`} className="w-full">
                    <Button variant="outline" className="w-full">
                      <Edit className="mr-2 h-4 w-4" />
                      Update Evaluation
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

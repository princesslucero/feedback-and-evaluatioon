"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Star } from "lucide-react"
import Header from "@/app/components/header"

interface Teacher {
  id: string
  name: string
  department: string
  subject: string
  rating: number
  feedback: string
}

export default function EvaluatePage({ params }: { params: { id: string } }) {
  const [teacher, setTeacher] = useState<Teacher | null>(null)
  const [rating, setRating] = useState(0)
  const [feedback, setFeedback] = useState("")
  const [hoveredRating, setHoveredRating] = useState(0)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Load teachers from localStorage
    const savedTeachers = JSON.parse(localStorage.getItem("teachers") || "[]")
    const foundTeacher = savedTeachers.find((t: Teacher) => t.id === params.id)

    if (foundTeacher) {
      setTeacher(foundTeacher)
      setRating(foundTeacher.rating)
      setFeedback(foundTeacher.feedback)
    } else {
      router.push("/dashboard")
    }
  }, [params.id, router])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!teacher) return

    // Get all teachers
    const allTeachers = JSON.parse(localStorage.getItem("teachers") || "[]")

    // Update the specific teacher
    const updatedTeachers = allTeachers.map((t: Teacher) => {
      if (t.id === teacher.id) {
        return { ...t, rating, feedback }
      }
      return t
    })

    // Save back to localStorage
    localStorage.setItem("teachers", JSON.stringify(updatedTeachers))

    toast({
      title: "Evaluation Saved",
      description: `Your evaluation for ${teacher.name} has been saved.`,
    })

    router.push("/dashboard")
  }

  if (!teacher) {
    return <div className="p-8 text-center">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-pink-100">
      <Header />

      <main className="container mx-auto p-4 py-8">
        <Card className="mx-auto max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-pink-600">Evaluate Teacher</CardTitle>
            <CardDescription>
              {teacher.name} • {teacher.department} • {teacher.subject}
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Rating</Label>
                <div className="flex items-center space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-8 w-8 cursor-pointer ${
                        star <= (hoveredRating || rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                      }`}
                      onClick={() => setRating(star)}
                      onMouseEnter={() => setHoveredRating(star)}
                      onMouseLeave={() => setHoveredRating(0)}
                    />
                  ))}
                  <span className="ml-2 text-sm font-medium">{rating > 0 ? `${rating}/5` : "Select a rating"}</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="feedback">Feedback</Label>
                <Textarea
                  id="feedback"
                  placeholder="Share your thoughts about this teacher..."
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  rows={5}
                  required
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button type="button" variant="outline" onClick={() => router.push("/dashboard")}>
                Cancel
              </Button>
              <Button type="submit" className="bg-pink-600 hover:bg-pink-700">
                Save Evaluation
              </Button>
            </CardFooter>
          </form>
        </Card>
      </main>
    </div>
  )
}

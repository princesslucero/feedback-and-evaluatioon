"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import Header from "@/app/components/header"

export default function AddTeacherPage() {
  const [name, setName] = useState("")
  const [department, setDepartment] = useState("")
  const [subject, setSubject] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Get existing teachers or initialize empty array
    const existingTeachers = JSON.parse(localStorage.getItem("teachers") || "[]")

    // Create new teacher object
    const newTeacher = {
      id: Date.now().toString(),
      name,
      department,
      subject,
      rating: 0,
      feedback: "",
    }

    // Add to existing teachers and save
    const updatedTeachers = [...existingTeachers, newTeacher]
    localStorage.setItem("teachers", JSON.stringify(updatedTeachers))

    toast({
      title: "Teacher Added",
      description: `${name} has been added successfully.`,
    })

    router.push("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-pink-100">
      <Header />

      <main className="container mx-auto p-4 py-8">
        <Card className="mx-auto max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-pink-600">Add New Teacher</CardTitle>
            <CardDescription>Enter the details of the teacher you want to evaluate</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Teacher Name</Label>
                <Input
                  id="name"
                  placeholder="Dr. Jane Smith"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="department">Department</Label>
                <Input
                  id="department"
                  placeholder="Computer Science"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  placeholder="Introduction to Programming"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  required
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full bg-pink-600 hover:bg-pink-700">
                Add Teacher
              </Button>
            </CardFooter>
          </form>
        </Card>
      </main>
    </div>
  )
}

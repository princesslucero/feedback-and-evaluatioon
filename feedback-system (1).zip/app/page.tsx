import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-pink-50 to-pink-100">
      <div className="w-full max-w-md space-y-8 rounded-lg bg-white p-8 shadow-lg">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-pink-600">Teacher Evaluation System</h1>
          <p className="mt-2 text-gray-600">Welcome, Princess Lucero</p>
        </div>
        <div className="space-y-4">
          <Link href="/login" className="w-full">
            <Button className="w-full bg-pink-600 hover:bg-pink-700">Login to Your Account</Button>
          </Link>
          <div className="text-center text-sm text-gray-500">
            A simple system to evaluate and provide feedback to your teachers
          </div>
        </div>
      </div>
    </div>
  )
}
